const cpen400a = require('./cpen400a-tester.js');
const path = require('path');
const fs = require('fs');
const express = require('express');

var chatrooms = [
	{	id: "0",
		name: "1",
		image: "2"
	},
	{	id: "1",
		name: "1",
		image: "2"
	}
];

var messages = {
	"0": [],
	"1": []
}



function logRequest(req, res, next){
	console.log(`${new Date()}  ${req.ip} : ${req.method} ${req.path}`);
	next();
}

const host = 'localhost';
const port = 3000;
const clientApp = path.join(__dirname, 'client');

// express app
let app = express();

app.use(express.json()) 						// to parse application/json
app.use(express.urlencoded({ extended: true })) // to parse application/x-www-form-urlencoded
app.use(logRequest);							// logging for debug

// serve static files (client-side)
app.use('/', express.static(clientApp, { extensions: ['html'] }));
app.listen(port, () => {
	console.log(`${new Date()}  App Started. Listening on ${host}:${port}, serving ${clientApp}`);
});

app.route('/chat')
	.get(function (req, res, next) {
		var room = [];
		chatrooms.forEach(element => {
			room.push({
					id: element.id, 
					name: element.name, 
					image: element.image, 
					messages: messages[element.id]
				});
		});
		console.log(room);
		res.status(200).json(room);
	});

cpen400a.connect('http://35.183.65.155/cpen400a/test-a3-server.js');
cpen400a.export(__filename, { app });
cpen400a.export(__filename,	{chatrooms});
cpen400a.export(__filename, { messages});